
<h1>Anna- School- Student nr</h1>     
<ul>
<li class="unimportant"> <a href="http://localhost:5173/InteractionsOverview">Interactions overview </a></li>
<li class="unimportant"><a href="http://localhost:5173/GeneOverview ">Gene overview</a></li>
</ul>